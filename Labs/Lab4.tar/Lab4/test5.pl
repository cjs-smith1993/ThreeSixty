#!/usr/bin/perl

print "Content-type: text/html\n\n";
print "<HTML>\n";
print "<HEAD>\n";
print "<TITLE>CGI Response page</TITLE>\n";
print "</HEAD>\n";
print "<Body>\n";

print "<P>CGI Response page</P>\n";
print "<hr>\n";

print "<P>This is a simple CGI script</P>\n";
print "<P> CGI: Common Gateway Interface</P>\n";
print "<ul>\n";
print "<li>A way to access databases, etc. on any computer. <\li>\n";
print "<li>Link to a program, not an HTML page. <\li>\n";
print "<li>Program runs and writes out a page in HTML. <\li>\n";
print "<li>You see the output page on your browser. <\li>\n";
print "</ul>\n";

print "</HTML>\n";
print "</Body>\n";
